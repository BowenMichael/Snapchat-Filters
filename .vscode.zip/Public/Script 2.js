// -----JS CODE-----
// @input SceneObject myObj

var pos = script.myObj.getTransform().getWorldPosition();

script.myObj.setTransform(1,1,1)