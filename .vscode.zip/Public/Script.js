// -----JS CODE-----
// @input float speed
// @input Asset.AnimationLayer
// @input function
// @input SceneObject myObj
// @input transf

print("hello world")

script.myObj.enabled = !script.myObj.enabled;
